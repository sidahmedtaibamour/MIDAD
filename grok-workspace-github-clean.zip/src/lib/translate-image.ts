import { createServerFn } from "@tanstack/react-start";

type FieldsInput = { kind: "fields"; subject: string; avoid: string };
type PromptInput = { kind: "prompt"; text: string };
type Input = FieldsInput | PromptInput;

const cache = new Map<string, string>();

function remember(key: string, value: string) {
  if (cache.has(key)) cache.delete(key);
  cache.set(key, value);
  if (cache.size > 40) {
    const oldest = cache.keys().next().value;
    if (oldest) cache.delete(oldest);
  }
}

function readInput(input: unknown): Input {
  const data = input as { kind?: string; subject?: unknown; avoid?: unknown; text?: unknown };
  if (data?.kind === "fields") {
    return {
      kind: "fields",
      subject: String(data.subject ?? "").trim().slice(0, 600),
      avoid: String(data.avoid ?? "").trim().slice(0, 300),
    };
  }
  return { kind: "prompt", text: String(data?.text ?? "").trim().slice(0, 1800) };
}

function parseFields(raw: string): { subject: string; avoid: string } | null {
  const cleaned = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
  try {
    const value = JSON.parse(cleaned) as { subject?: unknown; avoid?: unknown };
    if (typeof value.subject !== "string") return null;
    return {
      subject: value.subject.trim(),
      avoid: typeof value.avoid === "string" ? value.avoid.trim() : "",
    };
  } catch {
    return null;
  }
}

export const translateImagePrompt = createServerFn({ method: "POST" })
  .validator(readInput)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "الترجمة غير متاحة حاليًا." };

    const empty =
      data.kind === "fields" ? !data.subject && !data.avoid : !data.text;
    if (empty) return { ok: false as const, error: "اكتب الوصف بالعربي أول." };

    const cacheKey = JSON.stringify(data);
    const cached = cache.get(cacheKey);
    if (cached) return { ok: true as const, text: cached };

    const messages =
      data.kind === "fields"
        ? [
            {
              role: "system" as const,
              content:
                'Translate Arabic image-prompt fragments into concise English. Reply with JSON only, no markdown: {"subject":"...","avoid":"..."}. Do not add style, lighting, or camera words that are not in the input. If a field is empty, use "". If a field is already English, copy it.',
            },
            {
              role: "user" as const,
              content: `subject: ${data.subject}\navoid: ${data.avoid}`,
            },
          ]
        : [
            {
              role: "system" as const,
              content:
                'Turn the Arabic image description into an English diffusion prompt. Output only two parts: one paragraph, then a line that starts with "Negative:". Keep every concrete detail (materials, age, lens, light, colors, ratio). Do not explain or add a title.',
            },
            { role: "user" as const, content: data.text },
          ];

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.2,
        max_tokens: data.kind === "fields" ? 220 : 500,
        messages,
      }),
    });

    if (!res.ok) return { ok: false as const, error: "ما قدرت أترجم الحين. جرّب بعد قليل." };

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!raw) return { ok: false as const, error: "الترجمة رجعت فاضية." };

    const text = data.kind === "fields" ? JSON.stringify(parseFields(raw)) : raw;
    if (data.kind === "fields" && text === "null") {
      return { ok: false as const, error: "الترجمة ما طلعت مفهومة. جرّب مرة ثانية." };
    }

    remember(cacheKey, data.kind === "fields" ? raw : text);
    return { ok: true as const, text: data.kind === "fields" ? raw : text };
  });

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ArrowRight, Check, Copy, Search, Star } from "lucide-react";
import { translateImagePrompt } from "@/lib/translate-image";
import {
  BUILDER_BODY,
  BUILDER_SLOTS,
  CATEGORIES,
  FOLLOWUPS,
  FORMULA,
  LAYERS,
  SHORTCUTS,
  TEMPLATES,
  categoryLabel,
  fillTemplate,
  strengthScore,
  type CategoryId,
  type Slot,
  type Template,
} from "@/data/prompts";

type View = "library" | "images" | "builder" | "rules";
type Filter = "all" | "saved" | CategoryId;

const SAVED_KEY = "midad-saved";

const IMAGE_STYLES = [
  { id: "product", label: "منتج", en: "commercial product photography, crisp material detail" },
  { id: "cine", label: "سينمائي", en: "cinematic film still, anamorphic, subtle grain" },
  { id: "edit", label: "تحريري", en: "editorial photography, magazine crop" },
  { id: "oil", label: "زيتي", en: "oil painting, visible brushwork" },
  { id: "flat", label: "مسطّح", en: "flat vector illustration, bold simple shapes" },
  { id: "real", label: "واقعي", en: "photorealistic, natural texture" },
];

const IMAGE_LIGHTS = [
  { id: "window", label: "نافذة", en: "soft side-window light" },
  { id: "gold", label: "ذهبي", en: "golden-hour light" },
  { id: "studio", label: "استوديو", en: "soft studio light" },
  { id: "neon", label: "نيون", en: "night neon light" },
  { id: "hard", label: "درامي", en: "hard directional light, deep shadow" },
];

const IMAGE_LENSES = [
  { id: "35", label: "٣٥مم", en: "35mm" },
  { id: "50", label: "٥٠مم", en: "50mm" },
  { id: "85", label: "٨٥مم", en: "85mm" },
  { id: "macro", label: "ماكرو", en: "macro" },
];

const IMAGE_MOODS = [
  { id: "quiet", label: "هادئ", en: "quiet mood" },
  { id: "bold", label: "جريء", en: "bold mood" },
  { id: "warm", label: "دافئ", en: "warm melancholy" },
  { id: "luxe", label: "فاخر", en: "quiet luxury" },
];

const IMAGE_RATIOS = [
  { id: "1:1", label: "١:١", en: "square 1:1 frame" },
  { id: "4:5", label: "٤:٥", en: "4:5 portrait frame" },
  { id: "16:9", label: "١٦:٩", en: "16:9 wide frame" },
  { id: "9:16", label: "٩:١٦", en: "9:16 vertical frame" },
];

const IMAGE_PRESETS: {
  id: string;
  label: string;
  subject: string;
  style: string;
  light: string;
  lens: string;
  mood: string;
  ratio: string;
}[] = [
  {
    id: "coffee",
    label: "قهوة الصباح",
    subject: "فنجان قهوة سيراميك مطفي على حجر جيري دافئ",
    style: "product",
    light: "window",
    lens: "50",
    mood: "quiet",
    ratio: "4:5",
  },
  {
    id: "road",
    label: "غلاف طريق",
    subject: "طريق صحراوي فاضي وقت الغروب، وفيه مساحة فاضية على اليسار",
    style: "cine",
    light: "gold",
    lens: "35",
    mood: "warm",
    ratio: "16:9",
  },
  {
    id: "face",
    label: "بورتريه نافذة",
    subject: "امرأة في الثلاثين بقميص كتّان، تعبير هادئ، لقطة رأس وكتفين",
    style: "real",
    light: "window",
    lens: "85",
    mood: "quiet",
    ratio: "4:5",
  },
];

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
}

function Chip({
  active,
  onClick,
  children,
}: {
  active?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-11 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors ${
        active
          ? "border-foreground bg-foreground text-background"
          : "border-line bg-surface text-foreground hover:border-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function Score({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-3">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-line">
        <div
          className="h-full bg-accent transition-all duration-300"
          style={{ width: `${value}%` }}
        />
      </div>
      <span className="w-12 shrink-0 text-sm font-semibold tabular-nums">{value}٪</span>
    </div>
  );
}

function PromptCard({
  text,
  score,
  onCopy,
  copied,
  kicker = "البرومبت الجاهز",
}: {
  text: string;
  score: number;
  onCopy: () => void;
  copied: boolean;
  kicker?: string;
}) {
  return (
    <div className="rounded-card border border-line bg-foreground p-5 text-background">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="text-sm text-background/70">{kicker}</p>
        <p className="text-sm font-semibold tabular-nums">{score}٪</p>
      </div>
      <Score value={score} />
      <pre className="mt-5 max-h-96 overflow-auto whitespace-pre-wrap font-sans text-sm leading-relaxed text-background">
        {text}
      </pre>
      <button
        type="button"
        onClick={onCopy}
        className="mt-5 flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-accent px-4 text-sm font-semibold text-accent-foreground"
      >
        {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
        {copied ? "تم النسخ" : "انسخ البرومبت"}
      </button>
    </div>
  );
}

function SlotFields({
  slots,
  values,
  onChange,
}: {
  slots: Slot[];
  values: Record<string, string>;
  onChange: (key: string, value: string) => void;
}) {
  return (
    <div className="flex flex-col gap-4">
      {slots.map((slot) => (
        <label key={slot.key} className="flex flex-col gap-2">
          <span className="text-sm font-medium">{slot.label}</span>
          {slot.long ? (
            <textarea
              value={values[slot.key] ?? ""}
              onChange={(e) => onChange(slot.key, e.target.value)}
              placeholder={slot.placeholder}
              rows={4}
              className="w-full resize-y rounded-2xl border border-line bg-surface px-3 py-3 text-sm text-foreground outline-none placeholder:text-muted focus:border-foreground"
            />
          ) : (
            <input
              value={values[slot.key] ?? ""}
              onChange={(e) => onChange(slot.key, e.target.value)}
              placeholder={slot.placeholder}
              className="min-h-11 w-full rounded-2xl border border-line bg-surface px-3 text-sm text-foreground outline-none placeholder:text-muted focus:border-foreground"
            />
          )}
          {slot.suggestions && slot.suggestions.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {slot.suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => onChange(slot.key, suggestion)}
                  className="rounded-full border border-line bg-background px-3 py-1.5 text-xs text-muted hover:text-foreground"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}
        </label>
      ))}
    </div>
  );
}

function LayerToggles({
  active,
  onToggle,
}: {
  active: string[];
  onToggle: (id: string) => void;
}) {
  return (
    <div className="mt-6">
      <p className="text-sm font-medium">طبقات ترفع القوة</p>
      <p className="mt-1 text-sm text-muted">تُضاف أسفل البرومبت. فعّلها لما تبي الناتج أضبط.</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {LAYERS.map((layer) => (
          <Chip key={layer.id} active={active.includes(layer.id)} onClick={() => onToggle(layer.id)}>
            {layer.label}
          </Chip>
        ))}
      </div>
    </div>
  );
}

function assemble(body: string, slots: Slot[], values: Record<string, string>, layers: string[]) {
  const base = fillTemplate(body, slots, values);
  const extra = LAYERS.filter((layer) => layers.includes(layer.id)).map((layer) => `- ${layer.text}`);
  if (extra.length === 0) return base;
  return `${base}\n\nطبقات إضافية:\n${extra.join("\n")}`;
}

function readFields(raw: string): { subject: string; avoid: string } | null {
  const cleaned = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
  try {
    const value = JSON.parse(cleaned) as { subject?: unknown; avoid?: unknown };
    if (typeof value.subject !== "string") return null;
    return {
      subject: value.subject.trim(),
      avoid: typeof value.avoid === "string" ? value.avoid.trim() : "",
    };
  } catch {
    return null;
  }
}

function buildEnglishShot(
  scene: string,
  extra: string,
  styleId: string,
  lightId: string,
  lensId: string,
  moodId: string,
  ratioId: string,
) {
  const style = IMAGE_STYLES.find((item) => item.id === styleId) ?? IMAGE_STYLES[0];
  const light = IMAGE_LIGHTS.find((item) => item.id === lightId) ?? IMAGE_LIGHTS[0];
  const lens = IMAGE_LENSES.find((item) => item.id === lensId) ?? IMAGE_LENSES[0];
  const mood = IMAGE_MOODS.find((item) => item.id === moodId) ?? IMAGE_MOODS[0];
  const ratio = IMAGE_RATIOS.find((item) => item.id === ratioId) ?? IMAGE_RATIOS[0];
  const line = [
    scene,
    style.en,
    light.en,
    `shot on ${lens.en}`,
    mood.en,
    ratio.en,
    "highly detailed, natural texture, no text, no logo, no watermark",
  ].join(", ");
  const negative = `Negative: text, letters, watermark, logo, extra fingers, deformed anatomy, blur, plastic skin${extra ? `, ${extra}` : ""}`;
  return `${line}\n${negative}`;
}

export function Studio() {
  const [view, setView] = useState<View>("library");
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [layers, setLayers] = useState<string[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [subject, setSubject] = useState("فنجان قهوة سيراميك مطفي على حجر جيري دافئ");
  const [styleId, setStyleId] = useState("product");
  const [lightId, setLightId] = useState("window");
  const [lensId, setLensId] = useState("50");
  const [moodId, setMoodId] = useState("quiet");
  const [ratioId, setRatioId] = useState("4:5");
  const [avoid, setAvoid] = useState("");
  const [shotEn, setShotEn] = useState<{ key: string; subject: string; avoid: string } | null>(null);
  const [promptEn, setPromptEn] = useState<{ key: string; text: string } | null>(null);
  const [translating, setTranslating] = useState<"studio" | "template" | null>(null);
  const [translateError, setTranslateError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVED_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.every((item) => typeof item === "string")) {
          setSaved(parsed);
        }
      }
    } catch {
      /* ignore broken storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(SAVED_KEY, JSON.stringify(saved));
  }, [ready, saved]);

  useEffect(() => {
    if (!copied) return;
    const timer = window.setTimeout(() => setCopied(null), 1600);
    return () => window.clearTimeout(timer);
  }, [copied]);

  const selected = TEMPLATES.find((template) => template.id === selectedId) ?? null;

  const library = useMemo(() => {
    const q = query.trim();
    return TEMPLATES.filter((template) => {
      if (filter === "saved" && !saved.includes(template.id)) return false;
      if (filter !== "all" && filter !== "saved" && template.category !== filter) return false;
      if (!q) return true;
      const blob = `${template.title} ${template.promise} ${template.tip} ${categoryLabel(template.category)}`;
      return blob.includes(q);
    });
  }, [filter, query, saved]);

  const built = useMemo(() => {
    if (!selected) return "";
    return assemble(selected.body, selected.slots, values, layers);
  }, [selected, values, layers]);

  const builtScore = selected ? strengthScore(selected.slots, values, layers.length) : 0;

  const builderText = useMemo(
    () => assemble(BUILDER_BODY, BUILDER_SLOTS, values, layers),
    [values, layers],
  );
  const builderScore = strengthScore(BUILDER_SLOTS, values, layers.length);

  const fieldKey = `${subject.trim()}\n${avoid.trim()}`;
  const englishShot =
    shotEn && shotEn.key === fieldKey
      ? buildEnglishShot(shotEn.subject, shotEn.avoid, styleId, lightId, lensId, moodId, ratioId)
      : "";

  const arabicShot = useMemo(() => {
    const style = IMAGE_STYLES.find((item) => item.id === styleId) ?? IMAGE_STYLES[0];
    const light = IMAGE_LIGHTS.find((item) => item.id === lightId) ?? IMAGE_LIGHTS[0];
    const lens = IMAGE_LENSES.find((item) => item.id === lensId) ?? IMAGE_LENSES[0];
    const mood = IMAGE_MOODS.find((item) => item.id === moodId) ?? IMAGE_MOODS[0];
    const ratio = IMAGE_RATIOS.find((item) => item.id === ratioId) ?? IMAGE_RATIOS[0];
    const lines = [
      `الموضوع: ${subject.trim() || "〔الموضوع〕"}`,
      `الأسلوب: ${style.label}`,
      `الإضاءة: ${light.label}`,
      `العدسة: ${lens.label}`,
      `المزاج: ${mood.label}`,
      `الإطار: ${ratio.label}`,
    ];
    if (avoid.trim()) lines.push(`تجنّب: ${avoid.trim()}`);
    return lines.join("\n");
  }, [subject, styleId, lightId, lensId, moodId, ratioId, avoid]);

  const imageScore = useMemo(() => {
    const length = subject.trim().length;
    let score = 50;
    if (length > 12) score += 20;
    if (length > 40) score += 15;
    if (avoid.trim()) score += 15;
    return Math.min(100, score);
  }, [subject, avoid]);

  function flash(id: string) {
    setCopied(id);
  }

  async function copy(id: string, text: string) {
    await copyText(text);
    flash(id);
  }

  function openTemplate(template: Template) {
    setSelectedId(template.id);
    setValues({});
    setLayers([]);
    setPromptEn(null);
    setTranslateError(null);
    setView("library");
  }

  function setField(key: string, value: string) {
    setValues((current) => ({ ...current, [key]: value }));
  }

  function toggleLayer(id: string) {
    setLayers((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  function toggleSaved(id: string) {
    setSaved((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  function go(next: View) {
    setView(next);
    setSelectedId(null);
    setValues({});
    setLayers([]);
    setPromptEn(null);
    setTranslateError(null);
  }

  async function translateStudio() {
    const subjectText = subject.trim();
    if (!subjectText || translating) return;
    setTranslating("studio");
    setTranslateError(null);
    try {
      const result = await translateImagePrompt({
        data: { kind: "fields", subject: subjectText, avoid: avoid.trim() },
      });
      if (!result.ok) {
        setTranslateError(result.error);
        return;
      }
      const fields = readFields(result.text);
      if (!fields?.subject) {
        setTranslateError("الترجمة ما طلعت مفهومة. جرّب مرة ثانية.");
        return;
      }
      setShotEn({ key: `${subjectText}\n${avoid.trim()}`, subject: fields.subject, avoid: fields.avoid });
    } catch {
      setTranslateError("ما قدرت أترجم الحين. جرّب بعد قليل.");
    } finally {
      setTranslating(null);
    }
  }

  async function translateTemplate() {
    if (!built.trim() || translating) return;
    setTranslating("template");
    setTranslateError(null);
    try {
      const result = await translateImagePrompt({ data: { kind: "prompt", text: built } });
      if (!result.ok) {
        setTranslateError(result.error);
        return;
      }
      setPromptEn({ key: built, text: result.text });
    } catch {
      setTranslateError("ما قدرت أترجم الحين. جرّب بعد قليل.");
    } finally {
      setTranslating(null);
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-line bg-background">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <button type="button" onClick={() => go("library")} className="flex items-baseline gap-2">
            <span className="font-display text-3xl leading-none">مِداد</span>
            <span className="text-sm text-muted">١٠٠٪</span>
          </button>
          <nav className="flex gap-1 overflow-x-auto">
            {(
              [
                ["library", "القوالب"],
                ["images", "صور"],
                ["builder", "البنّاء"],
                ["rules", "اختصارات"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => go(id)}
                className={`min-h-11 shrink-0 rounded-full px-3 text-sm font-medium ${
                  view === id ? "bg-foreground text-background" : "text-muted hover:text-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 pb-16">
        {view === "library" && !selected && (
          <>
            <section className="pt-8">
              <p className="text-sm font-semibold text-accent">نصائح مختصرة، قوالب تُنسخ</p>
              <h1 className="mt-2 max-w-2xl text-4xl sm:text-5xl">
                خلّي الذكاء يخدمك صح، مو بالحظ.
              </h1>
              <p className="mt-3 max-w-2xl text-muted">
                ست خانات تصنع برومبت قوي: دور، سياق، مهمة، قيود، شكل، ومعيار. القالب يعبيهم عنك. انسخه والصقه في أي أداة.
              </p>
              <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
                {FORMULA.map((part) => (
                  <button
                    key={part.key}
                    type="button"
                    onClick={() => go("builder")}
                    className="min-h-11 shrink-0 rounded-2xl border border-line bg-surface px-3 text-right"
                  >
                    <span className="block text-sm font-semibold">{part.label}</span>
                    <span className="block text-xs text-muted">{part.hint}</span>
                  </button>
                ))}
              </div>
            </section>

            <div className="mt-6 flex flex-col gap-3">
              <label className="relative block">
                <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ابحث: إيميل، صور، دراسة، كود…"
                  className="min-h-11 w-full rounded-full border border-line bg-surface pr-10 pl-4 text-sm outline-none placeholder:text-muted focus:border-foreground"
                />
              </label>
              <div className="flex gap-2 overflow-x-auto pb-1">
                <Chip active={filter === "all"} onClick={() => setFilter("all")}>
                  الكل
                </Chip>
                <Chip active={filter === "saved"} onClick={() => setFilter("saved")}>
                  المحفوظ
                </Chip>
                {CATEGORIES.map((category) => (
                  <Chip
                    key={category.id}
                    active={filter === category.id}
                    onClick={() => setFilter(category.id)}
                  >
                    {category.label}
                  </Chip>
                ))}
              </div>
            </div>

            {library.length === 0 ? (
              <p className="mt-10 text-muted">
                ما لقينا قالب بهالوصف. افتح البنّاء وركّب برومبت من الصفر.
              </p>
            ) : (
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {library.map((template, index) => (
                  <li key={template.id}>
                    <article className="flex h-full flex-col rounded-card border border-line bg-surface p-5">
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-sm tabular-nums text-accent">
                          {String(index + 1).padStart(2, "0")} · {categoryLabel(template.category)}
                        </p>
                        <button
                          type="button"
                          aria-label={saved.includes(template.id) ? "إزالة من المحفوظ" : "حفظ القالب"}
                          onClick={() => toggleSaved(template.id)}
                          className="flex size-11 items-center justify-center rounded-full border border-line"
                        >
                          <Star
                            className={`size-4 ${saved.includes(template.id) ? "fill-accent text-accent" : "text-foreground"}`}
                          />
                        </button>
                      </div>
                      <h2 className="mt-3 text-2xl">{template.title}</h2>
                      <p className="mt-2 text-sm text-muted">{template.promise}</p>
                      <p className="mt-3 text-sm">{template.tip}</p>
                      <button
                        type="button"
                        onClick={() => openTemplate(template)}
                        className="mt-5 flex min-h-11 items-center justify-center rounded-full bg-foreground px-4 text-sm font-semibold text-background"
                      >
                        افتح القالب
                      </button>
                    </article>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}

        {view === "library" && selected && (
          <section className="pt-6">
            <button
              type="button"
              onClick={() => setSelectedId(null)}
              className="flex min-h-11 items-center gap-2 text-sm text-muted hover:text-foreground"
            >
              <ArrowRight className="size-4" />
              القوالب
            </button>
            <div className="mt-2 flex items-start justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-accent">{categoryLabel(selected.category)}</p>
                <h1 className="mt-1 text-4xl">{selected.title}</h1>
                <p className="mt-2 max-w-xl text-muted">{selected.tip}</p>
              </div>
              <button
                type="button"
                aria-label={saved.includes(selected.id) ? "إزالة من المحفوظ" : "حفظ القالب"}
                onClick={() => toggleSaved(selected.id)}
                className="flex size-11 shrink-0 items-center justify-center rounded-full border border-line bg-surface"
              >
                <Star
                  className={`size-4 ${saved.includes(selected.id) ? "fill-accent text-accent" : ""}`}
                />
              </button>
            </div>

            <div className="mt-6 grid items-start gap-6 lg:grid-cols-2">
              <div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setValues({ ...selected.example })}
                    className="min-h-11 rounded-full border border-foreground px-4 text-sm font-medium"
                  >
                    جرّب مثالًا جاهزًا
                  </button>
                  <button
                    type="button"
                    onClick={() => setValues({})}
                    className="min-h-11 rounded-full border border-line px-4 text-sm text-muted"
                  >
                    امسح الحقول
                  </button>
                </div>
                <div className="mt-5">
                  <SlotFields slots={selected.slots} values={values} onChange={setField} />
                </div>
                <LayerToggles active={layers} onToggle={toggleLayer} />
              </div>
              <div className="lg:sticky lg:top-24">
                <PromptCard
                  kicker={selected.category === "images" ? "الوصف بالعربي" : "البرومبت الجاهز"}
                  text={built}
                  score={builtScore}
                  copied={copied === selected.id}
                  onCopy={() => void copy(selected.id, built)}
                />
                {selected.category === "images" && (
                  <div className="mt-4">
                    <button
                      type="button"
                      onClick={() => void translateTemplate()}
                      disabled={translating === "template"}
                      className="flex min-h-11 w-full items-center justify-center rounded-full bg-accent px-4 text-sm font-semibold text-accent-foreground disabled:opacity-60"
                    >
                      {translating === "template" ? "يترجم…" : "ترجم للإنجليزية"}
                    </button>
                    {translateError && <p className="mt-2 text-sm text-accent">{translateError}</p>}
                    {promptEn && promptEn.key === built && (
                      <div className="mt-4">
                        <PromptCard
                          kicker="بالإنجليزية — للصق في نموذج الصور"
                          text={promptEn.text}
                          score={builtScore}
                          copied={copied === "template-en"}
                          onCopy={() => void copy("template-en", promptEn.text)}
                        />
                      </div>
                    )}
                    {promptEn && promptEn.key !== built && (
                      <p className="mt-2 text-sm text-muted">الوصف تغيّر. ترجم من جديد عشان يتحدّث الإنجليزي.</p>
                    )}
                  </div>
                )}
                <FollowUps onCopy={(text, id) => void copy(id, text)} copied={copied} />
              </div>
            </div>
          </section>
        )}

        {view === "images" && (
          <section className="pt-8">
            <p className="text-sm font-semibold text-accent">استوديو الصور</p>
            <h1 className="mt-2 max-w-2xl text-4xl sm:text-5xl">اكتب اللقطة بالعربي.</h1>
            <p className="mt-3 max-w-2xl text-muted">
              صف الموضوع والممنوع بلغتك. الأسلوب والضوء والعدسة تختارها من الأزرار. زر الترجمة يحوّل وصفك لإنجليزي جاهز، لأن نماذج الصور تفهمه أدق. لا تطلب نصًا داخل الصورة.
            </p>

            <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
              {IMAGE_PRESETS.map((preset) => (
                <Chip
                  key={preset.id}
                  onClick={() => {
                    setSubject(preset.subject);
                    setStyleId(preset.style);
                    setLightId(preset.light);
                    setLensId(preset.lens);
                    setMoodId(preset.mood);
                    setRatioId(preset.ratio);
                  }}
                >
                  {preset.label}
                </Chip>
              ))}
            </div>

            <div className="mt-6 grid items-start gap-6 lg:grid-cols-2">
              <div className="flex flex-col gap-5">
                <label className="flex flex-col gap-2">
                  <span className="text-sm font-medium">الموضوع بالعربي</span>
                  <textarea
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    rows={3}
                    className="w-full resize-y rounded-2xl border border-line bg-surface px-3 py-3 text-sm outline-none focus:border-foreground"
                  />
                </label>
                <Choice label="الأسلوب" options={IMAGE_STYLES} value={styleId} onChange={setStyleId} />
                <Choice label="الإضاءة" options={IMAGE_LIGHTS} value={lightId} onChange={setLightId} />
                <Choice label="العدسة" options={IMAGE_LENSES} value={lensId} onChange={setLensId} />
                <Choice label="المزاج" options={IMAGE_MOODS} value={moodId} onChange={setMoodId} />
                <Choice label="الإطار" options={IMAGE_RATIOS} value={ratioId} onChange={setRatioId} />
                <label className="flex flex-col gap-2">
                  <span className="text-sm font-medium">امنعه أيضًا</span>
                  <input
                    value={avoid}
                    onChange={(e) => setAvoid(e.target.value)}
                    placeholder="خلفية مزدحمة، فلاش قاسٍ"
                    className="min-h-11 rounded-2xl border border-line bg-surface px-3 text-sm outline-none placeholder:text-muted focus:border-foreground"
                  />
                </label>
              </div>
              <div className="lg:sticky lg:top-24">
                <div className="rounded-card border border-line bg-surface p-5">
                  <p className="text-sm font-medium">وصفك</p>
                  <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed">{arabicShot}</pre>
                  <button
                    type="button"
                    onClick={() => void translateStudio()}
                    disabled={translating === "studio" || !subject.trim()}
                    className="mt-4 flex min-h-11 w-full items-center justify-center rounded-full bg-accent px-4 text-sm font-semibold text-accent-foreground disabled:opacity-60"
                  >
                    {translating === "studio" ? "يترجم…" : "ترجم للإنجليزية"}
                  </button>
                  {translateError && view === "images" && (
                    <p className="mt-2 text-sm text-accent">{translateError}</p>
                  )}
                </div>
                {englishShot && (
                  <div className="mt-4">
                    <PromptCard
                      kicker="بالإنجليزية — للصق في نموذج الصور"
                      text={englishShot}
                      score={imageScore}
                      copied={copied === "image"}
                      onCopy={() => void copy("image", englishShot)}
                    />
                  </div>
                )}
                <p className="mt-3 text-sm text-muted">
                  الترجمة تصير مرة واحدة لما تضغط الزر، مو مع كل حرف. إذا غيّرت الموضوع، اضغط ترجم من جديد.
                </p>
              </div>
            </div>
          </section>
        )}

        {view === "builder" && (
          <section className="pt-8">
            <p className="text-sm font-semibold text-accent">البنّاء</p>
            <h1 className="mt-2 max-w-2xl text-4xl sm:text-5xl">أي طلب، نفس الست خانات.</h1>
            <p className="mt-3 max-w-2xl text-muted">
              إذا ما لقيت قالب جاهز، عبّي الخانات. الخانة الفاضية تبقى ظاهرة في البرومبت حتى تعرف وش ناقص قبل ما ترسل.
            </p>
            <div className="mt-6 grid items-start gap-6 lg:grid-cols-2">
              <div>
                <SlotFields slots={BUILDER_SLOTS} values={values} onChange={setField} />
                <LayerToggles active={layers} onToggle={toggleLayer} />
              </div>
              <div className="lg:sticky lg:top-24">
                <PromptCard
                  text={builderText}
                  score={builderScore}
                  copied={copied === "builder"}
                  onCopy={() => void copy("builder", builderText)}
                />
                <FollowUps onCopy={(text, id) => void copy(id, text)} copied={copied} />
              </div>
            </div>
          </section>
        )}

        {view === "rules" && (
          <section className="pt-8">
            <p className="text-sm font-semibold text-accent">ثمانية اختصارات</p>
            <h1 className="mt-2 max-w-2xl text-4xl sm:text-5xl">الفرق بين طلب ضعيف وطلب يُستخدم كما هو.</h1>
            <p className="mt-3 max-w-2xl text-muted">
              احفظها. بعد أي جواب، لا تقل «حسّنه». سمِّ الخلل: الطول، المثال، النبرة، أو الافتراض.
            </p>
            <ol className="mt-8 flex flex-col gap-4">
              {SHORTCUTS.map((item) => (
                <li key={item.n} className="rounded-card border border-line bg-surface p-5">
                  <p className="text-sm tabular-nums text-accent">{item.n}</p>
                  <h2 className="mt-1 text-2xl">{item.title}</h2>
                  <p className="mt-2 text-sm">{item.rule}</p>
                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    <div className="rounded-2xl border border-line bg-background p-4">
                      <p className="text-xs font-semibold text-muted">ضعيف</p>
                      <p className="mt-2 text-sm">{item.bad}</p>
                    </div>
                    <div className="rounded-2xl bg-foreground p-4 text-background">
                      <p className="text-xs font-semibold text-background/70">قوي — انسخه كنموذج</p>
                      <p className="mt-2 text-sm">{item.good}</p>
                      <button
                        type="button"
                        onClick={() => void copy(`rule-${item.n}`, item.good)}
                        className="mt-3 flex min-h-11 items-center gap-2 text-sm font-semibold text-accent-foreground"
                      >
                        {copied === `rule-${item.n}` ? <Check className="size-4" /> : <Copy className="size-4 text-accent" />}
                        {copied === `rule-${item.n}` ? "تم النسخ" : "انسخ القوي"}
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        )}
      </main>
    </div>
  );
}

function FollowUps({
  onCopy,
  copied,
}: {
  onCopy: (text: string, id: string) => void;
  copied: string | null;
}) {
  return (
    <div className="mt-4 rounded-card border border-line bg-surface p-4">
      <p className="text-sm font-medium">بعد أول جواب، الصق واحدًا من هذه</p>
      <ul className="mt-3 flex flex-col gap-2">
        {FOLLOWUPS.map((line, index) => {
          const id = `follow-${index}`;
          return (
            <li key={line}>
              <button
                type="button"
                onClick={() => onCopy(line, id)}
                className="flex min-h-11 w-full items-center justify-between gap-3 rounded-2xl border border-line bg-background px-3 text-right text-sm"
              >
                <span>{line}</span>
                {copied === id ? (
                  <Check className="size-4 shrink-0 text-accent" />
                ) : (
                  <Copy className="size-4 shrink-0 text-muted" />
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Choice({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div>
      <p className="text-sm font-medium">{label}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((option) => (
          <Chip key={option.id} active={value === option.id} onClick={() => onChange(option.id)}>
            {option.label}
          </Chip>
        ))}
      </div>
    </div>
  );
}
